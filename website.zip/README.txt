
Website Starter Pack — Hướng dẫn nhanh

1) Dùng ảnh:
- Hero: images/hero-1920x960.png (đặt làm ảnh nền phần mở đầu).
- Blog cover (ảnh đặc trưng Open Graph): images/blog-cover-1200x628.png.
- Card/Feature: images/card-800x600.png.
- Square 1:1: images/square-800x800.png.

2) Thêm CSS thương hiệu (không cần plugin):
- WordPress → Giao diện (Appearance) → Tùy biến (Customize) → Additional CSS → paste nội dung file style/brand.css.

3) Gợi ý bố cục Hero (dùng block Cover):
- Chèn block Cover → Select Media → dùng hero-1920x960.png → thêm lớp phủ (overlay) 40–55%.
- Thêm Heading 1 câu “Lời hứa giá trị”, 1 đoạn mô tả ngắn, 2 nút: “Dùng thử/Đặt lịch” và “Xem ví dụ”.
- Căn trái, giữ phần chữ trong vùng an toàn ~40–60% chiều ngang.

4) Kích thước đề xuất & tỷ lệ ảnh đặc trưng:
- Hero: 1920×960 hoặc 1920×800 (tỷ lệ ~2:1).
- Bài viết: 1200×628 (tỷ lệ 1.91:1 cho Open Graph), tối thiểu 1200px chiều ngang.
- Thẻ (card): 4:3 (800×600 hoặc 1200×900).
- Avatar/Đối tác: 1:1 (800×800).

5) Tối ưu ảnh:
- Xuất WebP nếu có thể (chất lượng 75–85). Đặt tên file-khong-dau, chứa từ khóa chính.
- Điền alt text mô tả ngắn gọn, có ý nghĩa.
- WordPress tự lazy-load ảnh; giữ dung lượng mỗi ảnh ≤ 300–350 KB cho ảnh nội dung.

6) Lưu ý thiết kế:
- Dùng 1 màu chính, 1 màu nhấn; giữ tông ảnh thống nhất (ánh sáng tự nhiên, ít filter gắt).
- Lặp lại phong cách: border-radius 12–16px, bóng đổ nhẹ, khoảng trắng rộng.
- Tương phản chữ–nền đủ lớn (AA).

Chúc bạn xây website đẹp, nhanh, và chuyên nghiệp!
